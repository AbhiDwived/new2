import WeddingVenues from "@/sections/WeddingVenues/WeddingVenues";

export default async function venues() {
    return <WeddingVenues />;
}
