import WeddingVenues from "@/sections/WeddingVenues/WeddingVenues";

export default function VenuesCityPage({ params }) {
    return <WeddingVenues params={params} />;
}