import VendorListPage from "@/sections/Location/VendorListPage";

export default function VenueAllCategory({ params }) {
    return <VendorListPage params={params} />;
}